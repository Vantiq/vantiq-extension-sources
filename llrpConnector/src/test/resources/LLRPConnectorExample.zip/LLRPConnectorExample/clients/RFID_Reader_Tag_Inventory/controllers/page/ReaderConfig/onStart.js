   var page = this;
        
    page.data.refreshReaderConfiguration = function(){
        console.log("Updating Reader Config");
        client.data.execute("cb.getReaderConfiguration", {}, function(response){
            client.sendClientEvent("ce_readerConfig", response);
        });
    };

    page.data.refreshReaderConfiguration();
    
    // clear previous timer if there is one
    if (page.data.timer)
        client.clearTimeout(page.data.timer);
    
    // refresh screen
    page.data.timer = client.setInterval(function() {
        page.data.refreshReaderConfiguration();
    }, 5000);
