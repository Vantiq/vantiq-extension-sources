    var page = this;
        
    page.data.refreshTagLocationHistory = function(){
        console.log("Updating Tag Location History");
        client.data.execute("cb.getTagLocationHistory", {}, function(response){
            client.sendClientEvent("ce_tagLocationHistory", response);
        });
    };

    page.data.refreshTagLocationHistory();
    
    // clear previous timer if there is one
    if (page.data.timer)
        client.clearTimeout(page.data.timer);
    
    // refresh screen
    page.data.timer = client.setInterval(function() {
        page.data.refreshTagLocationHistory();
    }, 5000);

    