
    var page = this;
    
    page.data.ReaderConfiguration.copyMatchingData(parameters);
    