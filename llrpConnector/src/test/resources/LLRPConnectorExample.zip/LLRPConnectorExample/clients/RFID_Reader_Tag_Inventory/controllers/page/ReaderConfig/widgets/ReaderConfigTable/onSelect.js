
    client.popupPage("ReaderConfigPopUp","Edit Reader Configuration", extra, function(response) {
        if (response != "CANCEL") {
            page.data.refreshReaderConfiguration();
        }
    });
    