
    
    // ************************************************************
    // General HTTP functions to call the server for database
    // and other functions.
    //
    client.data.execute = function(procedure, args, callback){
        var http = new Http();
        http.setVantiqUrlForSystemResource("procedures");
        http.setVantiqHeaders();

        http.execute(args,procedure,function(response){
            if(callback)
                callback(response);
        }, function(errors){
            console.log("Error while executing "+ procedure 
                         +": "+JSON.stringify(errors));
            //client.showHttpErrors(errors,"Executing '" + procedure + "'");
        });
    };
