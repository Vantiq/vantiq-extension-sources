    
    // Update the Reader Configuration
    var args = {};
    args.readerConfig = page.data.ReaderConfiguration.values;
    client.data.execute("cb.updateReaderConfiguration", args, function() {
        client.closePopup();
    });
    