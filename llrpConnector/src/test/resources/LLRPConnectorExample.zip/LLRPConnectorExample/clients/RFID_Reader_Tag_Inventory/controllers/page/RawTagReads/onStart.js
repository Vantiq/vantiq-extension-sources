    var page = this;
        
    page.data.refreshReaderTagHistory = function(){
        console.log("Updating Raw Tag History");
        client.data.execute("cb.getReaderEventHistory", {}, function(response){
            client.sendClientEvent("ce_readerTagHistory", response);
        });
    };

    page.data.refreshReaderTagHistory();
    
    // clear previous timer if there is one
    if (page.data.timer)
        client.clearTimeout(page.data.timer);
    
    // refresh screen
    page.data.timer = client.setInterval(function() {
        page.data.refreshReaderTagHistory();
    }, 5000);
