	var page = this;
    client.clearInterval(page.data.timer);
