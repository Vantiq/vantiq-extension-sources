    var page = this;
        
    page.data.refreshTagInventory = function(){
        console.log("Updating Tag Inventory");
        client.data.execute("cb.getTagInventory", {}, function(response){
            client.sendClientEvent("ce_tagInventory", response);
        });
    };

    page.data.refreshTagInventory();
    
    // clear previous timer if there is one
    if (page.data.timer)
        client.clearTimeout(page.data.timer);
    
    // refresh screen
    page.data.timer = client.setInterval(function() {
        page.data.refreshTagInventory();
    }, 5000);
